import javax.swing.JOptionPane;
public class Motocicleta extends Vehiculo implements PuedeCircular{
	private int potenciaMotor = 500;
	private boolean tieneMaletero = false;
	
	public void setPotenciaMotos(int potencia){
		potenciaMotor = potencia;
	}
	
	public int getPotenciaMotor(){
		return potenciaMotor;
	}
	
	public void setTieneMaletero(boolean maletero){
		tieneMaletero = maletero;
	}
	
	public boolean getTieneMaletero(){
		return tieneMaletero;
	}
	
	public String toString(Motocicleta mo){
		String carac = "La moto tiene las sigueintes caracteristicas: \nMatricula: " + super.getMatricula() + "\nMarca: " + super.getMarca() + "\nModelo: " + super.getModelo() + "\nColor: " + super.getColor() + "\nKilometros: " + super.getKilometros() + "\nNumero de Puertas: " + super.getNPuertas() + "\nNumero de Plazas: " + super.getNPlazas() + "\nPotencia del motor: " + getPotenciaMotor ()+ "cc\nTiene maletero: " + getTieneMaletero();
		return carac;
	}
	
	@Override public void circular(){
		JOptionPane.showMessageDialog(null, "Esto es una moto y puede circular por carreteras, autovias y autopistas");
	}
	
	public void brincar(){
		JOptionPane.showMessageDialog(null, "La motocicleta está brincando");
	}
	public Motocicleta(){}
	
	public Motocicleta(String matricula1, String marca1, String modelo1, String color1, double kilometros1, int numPuertas1, int numPlazas1, int potenciaMotor1, boolean tieneMaletero1){
		super(matricula1, marca1, modelo1, color1, kilometros1, numPuertas1, numPlazas1);
		potenciaMotor = potenciaMotor1;
		tieneMaletero = tieneMaletero1;
	}

}