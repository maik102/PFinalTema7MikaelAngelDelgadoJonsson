import javax.swing.JOptionPane;
public class Avioneta extends Vehiculo implements PuedeVolar{
	private String aeropuerto = "default";
	private double maxKG = 7000;
	
	public void setAeropuerto(String aero){
		aeropuerto = aero;
	}
	
	public String getAeropuerto(){
		return aeropuerto;
	}
	
	public void setMaxKG(double kg){
		maxKG = kg;
	}
	
	public double getMaxKG(){
		return maxKG;
	}
	
	public String toString(Avioneta av){
		String carac = "El avion tiene las sigueintes caracteristicas: \nMatricula: " + super.getMatricula() + "\nMarca: " + super.getMarca() + "\nModelo: " + super.getModelo() + "\nColor: " + super.getColor() + "\nKilometros: " + super.getKilometros() + "\nNumero de Puertas: " + super.getNPuertas() + "\nNumero de Plazas: " + super.getNPlazas() + "\nEl aeropuerto es: " + getAeropuerto ()+ "\nEl peso maximo es: " + getMaxKG();
		return carac;
	}
	
	@Override public void volar(){
		JOptionPane.showMessageDialog(null, "Esto es un avioneta y puede volar por el cielo");
	}
	
	public void despegar(){
		JOptionPane.showMessageDialog(null, "La avioneta está despegando");
	}
	
	public void aterrizar(){
		JOptionPane.showMessageDialog(null, "La avioneta está aterrizando");
	}
	
	public Avioneta(){}
	
	public Avioneta(String matricula1, String marca1, String modelo1, String color1, double kilometros1, int numPuertas1, int numPlazas1, String aeropuerto1, double maxKG1){
		super(matricula1, marca1, modelo1, color1, kilometros1, numPuertas1, numPlazas1);
		aeropuerto = aeropuerto1;
		maxKG = maxKG1;
	}
}