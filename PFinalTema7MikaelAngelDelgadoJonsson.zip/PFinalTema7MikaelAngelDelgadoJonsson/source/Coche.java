import javax.swing.JOptionPane;
public class Coche extends Vehiculo implements PuedeCircular{
	private int numAirbags = 5;
	private boolean techoSolar = false;
	private boolean tieneRadio = true;
	
	public void setNAirbags(int airbags){
		numAirbags = airbags;
	}
	
	public int getNAirbags(){
		return numAirbags;
	}
	
	public void setTechoSolar(boolean techo){
		techoSolar = techo;
	}
	
	public boolean getTechoSolar(){
		return techoSolar;
	}
	
	public void setTieneRadio(boolean radio){
		tieneRadio = radio;
	}
	
	public boolean getTieneRadio(){
		return tieneRadio;
	}
	
	public String toString(Coche co){
		String carac = "El coche tiene las sigueintes caracteristicas: \nMatricula: " + super.getMatricula() + "\nMarca: " + super.getMarca() + "\nModelo: " + super.getModelo() + "\nColor: " + super.getColor() + "\nKilometros: " + super.getKilometros() + "\nNumero de Puertas: " + super.getNPuertas() + "\nNumero de Plazas: " + super.getNPlazas() + "\nNumero de aribags: " + getNAirbags()+ "\nTiene teho solar: " + getTechoSolar() + "\nTiene radio: " + getTieneRadio();
		return carac;
	}
	
	@Override public void circular(){
		JOptionPane.showMessageDialog(null, "Esto es un coche y puede circular por carreteras, autovias y autopistas");
	}
	
	public void tunera(String color){
		super.setKilometros(0);
		super.setColor(JOptionPane.showInputDialog("¿De que color lo quieres pintar?"));
		JOptionPane.showMessageDialog(null, "Se ha puesto el cuenta kilometros a " + super.getKilometros() + " se ha pintado de color " + super.getColor());
		if(getTechoSolar() == false){
			setTechoSolar(true);
			JOptionPane.showMessageDialog(null, "Se ha instalado un techo solar");
		}
	}
	
	public void aparcar(){
		JOptionPane.showMessageDialog(null, "El coche ha sido aparcado correctamente");
	}
	
	public Coche(String matricula1, String marca1, String modelo1, String color1, double kilometros1, int numPuertas1, int numPlazas1, int numAirbags1, boolean techoSolar1, boolean tieneRadio1){
		super(matricula1, marca1, modelo1, color1, kilometros1, numPuertas1, numPlazas1);
		numAirbags = numAirbags1;
		techoSolar = techoSolar1;
		tieneRadio = tieneRadio1;
	}
	
	public Coche(){}
}