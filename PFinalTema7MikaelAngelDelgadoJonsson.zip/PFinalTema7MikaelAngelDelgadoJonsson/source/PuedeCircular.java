public interface PuedeCircular{
	public abstract void circular();
}