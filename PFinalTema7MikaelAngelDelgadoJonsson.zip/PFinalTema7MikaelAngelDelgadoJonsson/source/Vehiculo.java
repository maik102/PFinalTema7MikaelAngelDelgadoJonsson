abstract public class Vehiculo{
	private String matricula = "default";
	private String marca = "default";
	private String modelo = "default";
	private String color = "default";
	private double kilometros = 100;
	private int numPuertas = 3;
	private int numPlazas = 5;
	static int numVehiculos = 0;
	static final int maxVehiculos = 5;
	
	public void setMatricula(String mat){
		matricula = mat;
	}
	
	public String getMatricula(){
		return matricula;
	}
	
	public void setMarca(String ma){
		marca = ma;
	}
	
	public String getMarca(){
		return marca;
	}
	
	public void setModelo(String mo){
		modelo = mo;
	}
	
	public String getModelo(){
		return modelo;
	}
	
	public void setColor(String co){
		color = co;
	}
	
	public String getColor(){
		return color;
	}
	
	public void setKilometros(double km){
		kilometros = km;
	}
	
	public double getKilometros(){
		return kilometros;
	}
	
	public void setNPuertas(int puertas){
		numPuertas = puertas;
	}
	
	public int getNPuertas(){
		return numPuertas;
	}
	
	public void setNPlazas(int plazas){
		numPlazas = plazas;
	}
	
	public int getNPlazas(){
		return numPlazas;
	}
	
	public Vehiculo(String matricula1, String marca1, String modelo1, String color1, double kilometros1, int numPuertas1, int numPlazas1){
		matricula = matricula1;
		marca = marca1;
		modelo = modelo1;
		color = color1;
		kilometros = kilometros1;
		numPuertas = numPlazas1;
		numPlazas = numPlazas1;
		
		numVehiculos++;
	}
	
	public Vehiculo(){
		numVehiculos++;
	}
}