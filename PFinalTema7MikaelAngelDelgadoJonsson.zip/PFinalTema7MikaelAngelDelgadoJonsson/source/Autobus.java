import javax.swing.JOptionPane;
public class Autobus extends Vehiculo implements PuedeCircular{
	private String tipoRecorrido = "default";
	private boolean esEscolar = false;
	
	public void setTipoRecorrido(String recorrido){
		tipoRecorrido = recorrido;
	}
	
	public String getTipoRecorrido(){
		return tipoRecorrido;
	}
	
	public void setEsEscolar(boolean escolar){
		esEscolar = escolar;
	}
	
	public boolean getEsEscolar(){
		return esEscolar;
	}
	
	public String toString(Autobus au){
		String carac = "El bus tiene las sigueintes caracteristicas: \nMatricula: " + super.getMatricula() + "\nMarca: " + super.getMarca() + "\nModelo: " + super.getModelo() + "\nColor: " + super.getColor() + "\nKilometros: " + super.getKilometros() + "\nNumero de Puertas: " + super.getNPuertas() + "\nNumero de Plazas: " + super.getNPlazas() + "\nTipo recorrido: " + getTipoRecorrido ()+ "\nEs scolar: " + getEsEscolar();
		return carac;
	}
	
	@Override public void circular(){
		JOptionPane.showMessageDialog(null, "Esto es un autobus y puede circular por carreteras, autovias y autopistas");
	}
	
	public void abrirPuertas(){
		JOptionPane.showMessageDialog(null, "Las puertas se están abriendo");
	}
	
	public void aparcar(){
		JOptionPane.showMessageDialog(null, "El autobus ha sido aparcado correctamente");
	}
	
	public Autobus(String matricula1, String marca1, String modelo1, String color1, double kilometros1, int numPuertas1, int numPlazas1, String tipoRecorrido1, boolean esEscolar1){
		super(matricula1, marca1, modelo1, color1, kilometros1, numPuertas1, numPlazas1);
		tipoRecorrido = tipoRecorrido1;
		esEscolar = esEscolar1;
	}
	
	public Autobus(){}
}