public interface PuedeNavegar{
	public abstract void navegar();
}