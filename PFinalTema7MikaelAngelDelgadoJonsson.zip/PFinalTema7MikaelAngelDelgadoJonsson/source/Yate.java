import javax.swing.JOptionPane;
public class Yate extends Vehiculo{
	private boolean tieneCocina = true;
	private int numMotores = 10;
	private double metrosEslora = 300;
	
	public void setTieneCocina(boolean cocina){
		tieneCocina = cocina;
	}
	
	public boolean getTieneCocina(){
		return tieneCocina;
	}
	
	public void setNMotores(int motores){
		numMotores = motores;
	}
	
	public int getNMotores(){
		return numMotores;
	}
	
	public void setMetrosEslora(double eslora){
		metrosEslora = eslora;
	} 
	
	public double getMetrosEslora(){
		return metrosEslora;
	}
	
	public String toString(Yate y){
		String carac = "El yate tiene las sigueintes caracteristicas: \nMatricula: " + super.getMatricula() + "\nMarca: " + super.getMarca() + "\nModelo: " + super.getModelo() + "\nColor: " + super.getColor() + "\nKilometros: " + super.getKilometros() + "\nNumero de Puertas: " + super.getNPuertas() + "\nNumero de Plazas: " + super.getNPlazas() + "\nTiene cocina: " + getTieneCocina ()+ "\nNumero de motores: " + getNMotores() + "\nMetros de eslora: " + getMetrosEslora();
		return carac;
	}
	
	public void navegar(){
		JOptionPane.showMessageDialog(null, "Esto es un yate y puede navegar por todos los mares y oceanos");
	}
	
	public void zarpar(){
		JOptionPane.showMessageDialog(null, "El yate está zarpando");
	}
	
	public void atracar(){
		JOptionPane.showMessageDialog(null, "El yate está atracando");
	}
	
	public Yate(){}
	
	public Yate(String matricula1, String marca1, String modelo1, String color1, double kilometros1, int numPuertas1, int numPlazas1, boolean tieneCocina1, int numMotores1, double metrosEslora1){
		super(matricula1, marca1, modelo1, color1, kilometros1, numPuertas1, numPlazas1);
		tieneCocina = tieneCocina1;
		numMotores = numMotores1;
		metrosEslora = metrosEslora1;
	}
}