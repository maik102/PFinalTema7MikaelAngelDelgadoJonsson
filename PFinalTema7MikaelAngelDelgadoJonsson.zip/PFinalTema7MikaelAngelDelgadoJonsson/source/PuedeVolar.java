public interface PuedeVolar{
	public abstract void volar();
}