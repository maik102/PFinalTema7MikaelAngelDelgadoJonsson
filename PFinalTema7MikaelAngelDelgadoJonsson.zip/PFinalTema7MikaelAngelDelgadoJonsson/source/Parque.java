import javax.swing.JOptionPane;
import java.util.*;

public class Parque{
	public static void main(String[] args){
		int menuPrincipal = 0;
		int menuSecundario = 0;
		String matricula;
		String marca;
		String modelo;
		String color;
		double kilometros;
		int numPuertas;
		int numPlazas;
		int numAirbags;
		boolean techoSolar;
		boolean tieneRadio;
		String tipoRecorrido;
		boolean esEscolar;
		int potenciaMotor;
		boolean tieneMaletero;
		String aeropuerto;
		double maxKG;
		boolean tieneCocina;
		int numMotores;
		double metrosEslora;
		
		ArrayList<Vehiculo> parque = new ArrayList<Vehiculo>();
		
		do{			
			try{
				menuPrincipal = Integer.parseInt(JOptionPane.showInputDialog("Selecciona una de las siguientes opciones: \n1.Crear coche(con o sin datos) \n2.Crear autobus (con o sin datos) \n3.Crear motocicleta (con o sin datos) \n4.Crear avioneta (con o sin datos) \n5.Crear yate (con o sin datos) \n6.Mostrar características de todos los vehículos del parque\n7.Ver cuantos vehiculos hay en el parque\n8.Buscar un vehiculo por su matricula. \n9.Salir del programa"));
				switch(menuPrincipal){
							
					case 1: 
						if(Vehiculo.numVehiculos == Vehiculo.maxVehiculos){
							JOptionPane.showMessageDialog(null, "El parque esta lleno, no se pueden crear mas vehiculos.");
						}else{										
							do{			
								try{
									menuSecundario = Integer.parseInt(JOptionPane.showInputDialog("\n1.Crear coche sin datos \n2.Crear coche con datos\n3.Volver atras"));
									switch(menuSecundario){
																					
										case 1:
											Vehiculo coche = new Coche();
											parque.add(coche);	
											JOptionPane.showMessageDialog(null, coche.toString());
										break;
							
										case 2:
											matricula = JOptionPane.showInputDialog("Introduzca la matricula:");
											marca = JOptionPane.showInputDialog("Introduzca la marca:");
											modelo = JOptionPane.showInputDialog("Introduzca el modelo:");
											color = JOptionPane.showInputDialog("Introduzca el color:");
											kilometros = Double.parseDouble(JOptionPane.showInputDialog("Introduzca los kilometros:"));
											numPuertas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las puertas:"));
											numPlazas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las plazas:"));
											numAirbags = Integer.parseInt(JOptionPane.showInputDialog("Introduzca los airbags:"));
											String techo = JOptionPane.showInputDialog("Introduzca 's' si quiere techo solar o 'n' si no:");
											if(techo.equals("s")){
												techoSolar = true;
											}else{
												techoSolar = false;
											}
											String radio = JOptionPane.showInputDialog("Introduzca 's' si quiere radio solar o 'n' si no:");
											if(radio.equals("s")){
												tieneRadio = true;
											}else{
												tieneRadio = false;
											}
											
											Vehiculo coche1 = new Coche(matricula, marca, modelo, color, kilometros, numPuertas, numPlazas, numAirbags, techoSolar, tieneRadio);
											parque.add(coche1);
										break;
										
										case 3:
											JOptionPane.showMessageDialog(null, "Volviendo al menu principal");
										break;
									}								
								}catch(Exception e){
									JOptionPane.showMessageDialog(null, "Debes introducir un valor numerico");
								}								
							}while(menuSecundario != 3);
						}
												
					case 2:
						if(Vehiculo.numVehiculos == Vehiculo.maxVehiculos){
							JOptionPane.showMessageDialog(null, "El parque esta lleno, no se pueden crear mas vehiculos.");
						}else{
							do{			
								try{
									menuSecundario = Integer.parseInt(JOptionPane.showInputDialog("\n1.Crear autobus sin datos \n2.Crear autobus con datos\n3.Volver atras"));
									switch(menuSecundario){
											
										case 1:
											Vehiculo bus = new Autobus();
											parque.add(bus);	
										break;
							
										case 2:
											matricula = JOptionPane.showInputDialog("Introduzca la matricula:");
											marca = JOptionPane.showInputDialog("Introduzca la marca:");
											modelo = JOptionPane.showInputDialog("Introduzca el modelo:");
											color = JOptionPane.showInputDialog("Introduzca el color:");
											kilometros = Double.parseDouble(JOptionPane.showInputDialog("Introduzca los kilometros:"));
											numPuertas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las puertas:"));
											numPlazas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las plazas:"));
											tipoRecorrido = JOptionPane.showInputDialog("Introduzca el tipo de recorrido:");
											String es = JOptionPane.showInputDialog("Introduzca 's' si quiere techo solar o 'n' si no:");
											if(es.equals("s")){
												esEscolar = true;
											}else{
												esEscolar = false;
											}											
											
											Vehiculo bus1 = new Autobus(matricula, marca, modelo, color, kilometros, numPuertas, numPlazas, tipoRecorrido, esEscolar);
											parque.add(bus1);
										break;
										
										case 3:
											JOptionPane.showMessageDialog(null, "Volviendo al menu principal");
										break;
									}								
								}catch(Exception e){
									JOptionPane.showMessageDialog(null, "Debes introducir un valor numerico");
								}								
							}while(menuSecundario != 3);
						}
						break;
								
					case 3:
						if(Vehiculo.numVehiculos == Vehiculo.maxVehiculos){
							JOptionPane.showMessageDialog(null, "El parque esta lleno, no se pueden crear mas vehiculos.");
						}else{
							do{			
								try{
									menuSecundario = Integer.parseInt(JOptionPane.showInputDialog("\n1.Crear motocicleta sin datos \n2.Crear motocicleta con datos\n3.Volver atras"));
									switch(menuSecundario){
											
										case 1:
											Vehiculo moto = new Motocicleta();
											parque.add(moto);
										break;
							
										case 2:
											matricula = JOptionPane.showInputDialog("Introduzca la matricula:");
											marca = JOptionPane.showInputDialog("Introduzca la marca:");
											modelo = JOptionPane.showInputDialog("Introduzca el modelo:");
											color = JOptionPane.showInputDialog("Introduzca el color:");
											kilometros = Double.parseDouble(JOptionPane.showInputDialog("Introduzca los kilometros:"));
											numPuertas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las puertas:"));
											numPlazas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las plazas:"));
											potenciaMotor = Integer.parseInt(JOptionPane.showInputDialog("Introduzca la potencia del motor:"));
											String ma = JOptionPane.showInputDialog("Introduzca 's' si quiere maletero o 'n' si no:");
											if(ma.equals("s")){
												tieneMaletero = true;
											}else{
												tieneMaletero = false;
											}											
											
											Vehiculo moto1 = new Motocicleta(matricula, marca, modelo, color, kilometros, numPuertas, numPlazas, potenciaMotor, tieneMaletero);
											parque.add(moto1);
										break;
										
										case 3:
											JOptionPane.showMessageDialog(null, "Volviendo al menu principal");
										break;
									}								
								}catch(Exception e){
									JOptionPane.showMessageDialog(null, "Debes introducir un valor numerico");
								}								
							}while(menuSecundario != 3);
						}
						break;
								
					case 4: 
						if(Vehiculo.numVehiculos == Vehiculo.maxVehiculos){
							JOptionPane.showMessageDialog(null, "El parque esta lleno, no se pueden crear mas vehiculos.");
						}else{
							do{			
								try{
									menuSecundario = Integer.parseInt(JOptionPane.showInputDialog("\n1.Crear avioenta sin datos \n2.Crear avioneta con datos\n3.Volver atras"));
									switch(menuSecundario){
											
										case 1:
											Vehiculo avion = new Avioneta();
											parque.add(avion);
										break;
							
										case 2:
											matricula = JOptionPane.showInputDialog("Introduzca la matricula:");
											marca = JOptionPane.showInputDialog("Introduzca la marca:");
											modelo = JOptionPane.showInputDialog("Introduzca el modelo:");
											color = JOptionPane.showInputDialog("Introduzca el color:");
											kilometros = Double.parseDouble(JOptionPane.showInputDialog("Introduzca los kilometros:"));
											numPuertas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las puertas:"));
											numPlazas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las plazas:"));
											aeropuerto = JOptionPane.showInputDialog("Introduzca el aropeurto:");
											maxKG = Integer.parseInt(JOptionPane.showInputDialog("Introduzca el peso maximo:"));
																						
											Vehiculo avion1 = new Avioneta(matricula, marca, modelo, color, kilometros, numPuertas, numPlazas, aeropuerto, maxKG);
											parque.add(avion1);
										break;
										
										case 3:
											JOptionPane.showMessageDialog(null, "Volviendo al menu principal");
										break;
									}								
								}catch(Exception e){
									JOptionPane.showMessageDialog(null, "Debes introducir un valor numerico");
								}								
							}while(menuSecundario != 3);
						}
						break;
								
					case 5:
						if(Vehiculo.numVehiculos == Vehiculo.maxVehiculos){
							JOptionPane.showMessageDialog(null, "El parque esta lleno, no se pueden crear mas vehiculos.");
						}else{
							do{			
								try{
									menuSecundario = Integer.parseInt(JOptionPane.showInputDialog("\n1.Crear yate sin datos \n2.Crear yate con datos\n3.Volver atras"));
									switch(menuSecundario){
											
										case 1:
											Vehiculo yate = new Yate();
											parque.add(yate);
										break;
							
										case 2:
											matricula = JOptionPane.showInputDialog("Introduzca la matricula:");
											marca = JOptionPane.showInputDialog("Introduzca la marca:");
											modelo = JOptionPane.showInputDialog("Introduzca el modelo:");
											color = JOptionPane.showInputDialog("Introduzca el color:");
											kilometros = Double.parseDouble(JOptionPane.showInputDialog("Introduzca los kilometros:"));
											numPuertas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las puertas:"));
											numPlazas = Integer.parseInt(JOptionPane.showInputDialog("Introduzca las plazas:"));
											String cocina = JOptionPane.showInputDialog("Introduzca el aropeurto:");
											if(cocina.equals("s")){
												tieneCocina = true;
											}else{
												tieneCocina = false;
											}	
											numMotores = Integer.parseInt(JOptionPane.showInputDialog("Introduzca el numero de motores:"));
											metrosEslora = Double.parseDouble(JOptionPane.showInputDialog("Introduzca los metros de eslora:"));
											
											Vehiculo yate1 = new Yate(matricula, marca, modelo, color, kilometros, numPuertas, numPlazas, tieneCocina, numMotores, metrosEslora);
											parque.add(yate1);
										break;
										
										case 3:
											JOptionPane.showMessageDialog(null, "Volviendo al menu principal");
										break;
									}								
								}catch(Exception e){
									JOptionPane.showMessageDialog(null, "Debes introducir un valor numerico");
								}								
							}while(menuSecundario != 3);
						}
						break;
								
					case 6:
						for(int i = 0; i < parque.size(); i++){
							JOptionPane.showMessageDialog(null, parque.get(i).toString());
						}						
						break;
						
					case 7:
						JOptionPane.showMessageDialog(null, "En el parque hay " + Vehiculo.numVehiculos + " vehiculos.");
						
						break;
						
					case 8:
						String matBuscada = JOptionPane.showInputDialog("Introduce la matricula del vehiculo deseado: ");
						for(int j=0; j<parque.size(); j++){
							Vehiculo v = parque.get(j);
							if(matBuscada.equals(v.getMatricula())){
								JOptionPane.showMessageDialog(null, parque.get(j).toString());
							}else{
								JOptionPane.showMessageDialog(null, "El vehiculo especificado no se encuentra en el garaje");
							}
						}
						break;
						
					case 9:
						JOptionPane.showMessageDialog(null, "Gracias por utilizar el programa.");
						break;
							
					default:
						JOptionPane.showMessageDialog(null, "El numero introducido no es valido");
						break;
						
				}
			}catch(Exception e){
				JOptionPane.showMessageDialog(null, "Debes introducir un valor numerico");
			}
		}while(menuPrincipal != 9);
	}
}